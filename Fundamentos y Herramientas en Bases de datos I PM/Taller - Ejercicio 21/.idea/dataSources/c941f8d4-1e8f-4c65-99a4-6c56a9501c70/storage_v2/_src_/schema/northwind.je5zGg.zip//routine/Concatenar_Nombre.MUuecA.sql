create
    definer = admin@`%` function Concatenar_Nombre(FirstName varchar(20), LastName varchar(20)) returns varchar(40)
    deterministic
BEGIN
    DECLARE NOMBRE_COMPLETO VARCHAR(40);
    SET NOMBRE_COMPLETO = CONCAT(FirstName, ' ', LastName);
    RETURN NOMBRE_COMPLETO;
END;

