create
    definer = admin@`%` function Calcular_edad(BirthDate date) returns int deterministic
BEGIN
    DECLARE EDAD INT;
    SET EDAD = TIMESTAMPDIFF(YEAR, BirthDate, CURDATE());
    RETURN EDAD;
END;

